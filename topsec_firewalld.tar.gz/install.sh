#!/bin/bash
firewall-cmd --add-port=8080/tcp --permanent
systemctl restart nginx
systemctl restart firewalld
